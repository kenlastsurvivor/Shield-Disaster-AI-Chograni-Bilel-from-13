from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from flask_cors import CORS
import joblib
import numpy as np

app = Flask(__name__)
CORS(app)
app.config['JWT_SECRET_KEY'] = 'change_this_to_a_strong_secret_key'
jwt = JWTManager(app)
users = {}

# Charger le modèle ML (ou remplace par une fonction fictive)
try:
    model = joblib.load('model_random_forest.pkl')
except Exception:
    model = None

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"error": "Nom d'utilisateur et mot de passe requis"}), 400
    if username in users:
        return jsonify({"error": "Utilisateur déjà existant"}), 409
    users[username] = {'password': password}
    msg = f"Merci et bienvenue {username}! Toute l’équipe te souhaite la bienvenue dans le projet."
    print(msg)
    return jsonify({"message": msg}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user = users.get(username)
    if not user or user['password'] != password:
        return jsonify({"error": "Identifiants invalides"}), 401
    access_token = create_access_token(identity=username)
    return jsonify(access_token=access_token)

@app.route('/predict-earthquake', methods=['POST'])
@jwt_required()
def predict():
    if model is None:
        # Prédiction fictive si pas de modèle
        return jsonify({"alert": 0, "note": "Modèle ML non disponible, valeur fictive retournée."}), 200
    data = request.get_json()
    if not data or 'vibrations' not in data:
        return jsonify({'error': 'Données de vibrations manquantes.'}), 400
    try:
        vibrations = np.array(data['vibrations']).reshape(1, -1)
        prediction = model.predict(vibrations)
        return jsonify({"alert": int(prediction[0])})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)