# Bienvenue sur l’application Sismique 🚀

- Inscris-toi, connecte-toi.
- Prédit les risques sismiques à partir de tes données.
- Toute l’équipe te souhaite la bienvenue et te remercie de rejoindre l’aventure !

Pour toute question : contact dans le repo GitHub.