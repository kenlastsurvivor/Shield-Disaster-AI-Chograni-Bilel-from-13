import React, { useState } from "react";
import axios from "axios";

const API_URL = "http://localhost:5000"; // Remplace par ton URL de backend déployée

export default function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [message, setMessage] = useState("");
  const [vibrations, setVibrations] = useState("");
  const [prediction, setPrediction] = useState(null);

  const register = async () => {
    try {
      const { data } = await axios.post(`${API_URL}/register`, { username, password });
      setMessage(data.message);
    } catch (e) {
      setMessage(e.response?.data?.error || "Erreur à l'inscription");
    }
  };

  const login = async () => {
    try {
      const { data } = await axios.post(`${API_URL}/login`, { username, password });
      setToken(data.access_token);
      setMessage("Connecté !");
    } catch (e) {
      setMessage(e.response?.data?.error || "Erreur de connexion");
    }
  };

  const predict = async () => {
    try {
      const { data } = await axios.post(
        `${API_URL}/predict-earthquake`,
        { vibrations: vibrations.split(",").map(Number) },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setPrediction(data);
    } catch (e) {
      setMessage(e.response?.data?.error || "Erreur prédiction");
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Inscription / Connexion</h2>
      <input placeholder="Nom d'utilisateur" value={username} onChange={e => setUsername(e.target.value)} />
      <input placeholder="Mot de passe" type="password" value={password} onChange={e => setPassword(e.target.value)} />
      <button onClick={register}>S'inscrire</button>
      <button onClick={login}>Se connecter</button>
      <p>{message}</p>
      {token && (
        <>
          <h2>Prédiction Sismique</h2>
          <input placeholder="Liste de vibrations (ex: 0.1,0.2,0.3)" value={vibrations} onChange={e => setVibrations(e.target.value)} />
          <button onClick={predict}>Prédire</button>
          {prediction && <pre>{JSON.stringify(prediction, null, 2)}</pre>}
        </>
      )}
    </div>
  );
}